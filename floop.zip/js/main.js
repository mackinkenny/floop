$(document).ready(function () {

    $.ajax({
        type: 'GET',
        url: '/is-subs',
        data: {
            'id': $('#sid').val(),
            'b_id': $('#sb_id').val(),
            'u_id': $('#su_id').val()
        },
        dataType: 'json',
        success: function (data) {
            if (data.subs_flag) {
                $('#subs-flag').text('Отписаться')
            }
            else {
                $('#subs-flag').text('Подписаться')
            }
            $('.sub-badge').text(data.subs_count)
        }
    })

    $('.modal.fade').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)
        var modal = $(this)
        $.ajax({
            url: '/products/' + button.data('id') + '',
            type: 'GET',
            success: function (data) {
                var i = 0
                modal.find('.carousel-inner').empty()
                modal.find('.carousel-indicators').empty()
                for (var photo of data.photos) {
                    if (i === 0) {
                        modal.find('.carousel-inner').append(
                            '<div class="carousel-item active">' +
                            '<img class="d-block w-100" src="/uploads/images/products/' + photo.img_path + '">' +
                            '</div>'
                        )
                        modal.find('.carousel-indicators').append(
                            '<li data-target="#carouselExampleIndicators" data-slide-to="' + i + '" class="active"></li>'
                        )
                    }
                    else {
                        modal.find('.carousel-inner').append(
                            '<div class="carousel-item">' +
                            '<img class="d-block w-100" src="/uploads/images/products/' + photo.img_path + '">' +
                            '</div>'
                        )
                        modal.find('.carousel-indicators').append(
                            '<li data-target="#carouselExampleIndicators" data-slide-to="' + i + '"></li>'
                        )
                    }
                    i++

                }
                modal.find('.h4-text').text(data.boutic.name)
                modal.find('.size-text').text(' ' + data.size)
                modal.find('.brand-text').text(' ' + data.brand)
                modal.find('.color-text').text(' ' + data.color)
                modal.find('.product-boutic').text(data.product.name + ' ОТ ' + data.boutic.name)
                modal.find('#lid').val(data.product.id)
                modal.find('#lu_id').val(data.user)
                modal.find('#bid').val(data.product.id)
                modal.find('#bu_id').val(data.user)
                modal.find('.price-text').text(data.product.price)

            }
        })
    })

    $('#like').click(function (e) {
        e.preventDefault(e);
        $.ajax({
            type: 'POST',
            url: '/like',
            data: {
               'id': $('#lid').val(),
               'u_id': $('#lu_id').val()
            },
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            },
            dataType: 'json',
            success: function (data) {
               alert('it works!' + data.Success);
               $('.like_count').text('| ' + data.like_count)
            },
        });
    });

    $('#buy').click(function (e) {
        e.preventDefault(e);
        $.ajax({
            type: 'POST',
            url: '/buy',
            data: {
                'id': $('#bid').val(),
                'u_id': $('#bu_id').val()
            },
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            },
            dataType: 'json',
            success: function (data) {
                alert('it works!' + data.Success);
            },
        });
    });


    $('#sub').click(function (e) {
        e.preventDefault(e);
        $.ajax({
            type: 'POST',
            url: '/subscribe',
            data: {
                'id': $('#sid').val(),
                'b_id': $('#sb_id').val(),
                'u_id': $('#su_id').val()
            },
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            },
            dataType: 'json',
            success: function (data) {
                if (!data.subs_flag) {
                    $('#subs-flag').text('Отписаться')
                }
                else {
                    $('#subs-flag').text('Подписаться')
                }
                $('.sub-badge').text(data.subs_count)
            },
        });
    });

});